# LearnNepal---Online-Nepali-Learing-Platform
This project was done to create a prototype for a  online learning platform. HTML, CSS and JavaScript are used. 
